package com.atguigu.mybatis.mapper;

import com.atguigu.mybatis.entities.Employee;

public interface EmployeeMapper {

	Employee getEmployeeById(Integer id);
}
